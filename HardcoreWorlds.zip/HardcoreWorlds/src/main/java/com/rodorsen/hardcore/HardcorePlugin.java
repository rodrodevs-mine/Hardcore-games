package com.rodorsen.hardcore;

import org.bukkit.plugin.java.JavaPlugin;

public class HardcorePlugin extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("Hardcore plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("Hardcore plugin disabled!");
    }
}
